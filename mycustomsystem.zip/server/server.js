const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.resolve(__dirname, '../')));

// --- Auth Routes ---

app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    db.get("SELECT * FROM users WHERE username = ? AND password = ?", [username, password], (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        if (row) {
            res.json(row);
        } else {
            res.status(401).json({ error: "Invalid credentials" });
        }
    });
});

app.post('/api/auth/register', (req, res) => {
    const { username, password } = req.body;
    const role = 'user'; // Force user role for self-registration
    db.run("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", [username, password, role], function(err) {
        if (err) {
            if (err.message.includes('UNIQUE constraint')) {
                return res.status(400).json({ error: "Username already exists" });
            }
            return res.status(500).json({ error: err.message });
        }
        res.json({ username, password, role });
    });
});

app.get('/api/users', (req, res) => {
    db.all("SELECT username, password, role FROM users", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// --- Company Routes ---

// List Companies (Filtered by query params handled in frontend usually, but good to have)
app.get('/api/companies', (req, res) => {
        const query = `SELECT 
                id,
                name,
                created_at as createdAt,
                created_by as createdBy,
                last_modified as lastModified,
                last_modified_by as lastModifiedBy
            FROM companies`;
        db.all(query, [], (err, companies) => {
        if (err) return res.status(500).json({ error: err.message });
        
        // Fetch shareholders for each company
        // This is the N+1 problem but SQLite is local and fast, simple solution:
        const promises = companies.map(comp => {
            return new Promise((resolve, reject) => {
                db.all("SELECT * FROM shareholders WHERE company_id = ?", [comp.id], (err, rows) => {
                    if (err) reject(err);
                    else {
                        comp.shareholders = rows;
                        resolve(comp);
                    }
                });
            });
        });

        Promise.all(promises)
            .then(results => res.json(results))
            .catch(err => res.status(500).json({ error: err.message }));
    });
});

app.get('/api/companies/:id', (req, res) => {
    const { id } = req.params;
    db.get(
        `SELECT 
            id,
            name,
            created_at as createdAt,
            created_by as createdBy,
            last_modified as lastModified,
            last_modified_by as lastModifiedBy
         FROM companies WHERE id = ?`,
        [id],
        (err, company) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!company) return res.status(404).json({ error: "Company not found" });

        db.all("SELECT * FROM shareholders WHERE company_id = ?", [id], (err, rows) => {
            if (err) return res.status(500).json({ error: err.message });
            company.shareholders = rows;
            res.json(company);
        });
    });
});

app.post('/api/companies', (req, res) => {
    const { id, name, createdAt, createdBy, shareholders } = req.body;
    
    db.serialize(() => {
        const stmt = db.prepare("INSERT INTO companies (id, name, created_at, created_by) VALUES (?, ?, ?, ?)");
        stmt.run(id, name, createdAt, createdBy, function(err) {
            if (err) return res.status(500).json({ error: err.message });
            
            const shStmt = db.prepare("INSERT INTO shareholders (id, company_id, name, phone, share, stage, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
            
            if (shareholders && shareholders.length > 0) {
                shareholders.forEach(sh => {
                    shStmt.run(sh.id, id, sh.name, sh.phone, sh.share, sh.stage, sh.notes);
                });
            }
            
            shStmt.finalize();
            res.json({ success: true });
        });
        stmt.finalize();
    });
});

app.put('/api/companies/:id', (req, res) => {
    const { id } = req.params;
    const { name, lastModified, lastModifiedBy, shareholders } = req.body;

    db.serialize(() => {
        // Update Company
        db.run("UPDATE companies SET name = ?, last_modified = ?, last_modified_by = ? WHERE id = ?", 
            [name, lastModified, lastModifiedBy, id], 
            (err) => {
                if (err) return res.status(500).json({ error: err.message });
            }
        );

        // Replace Shareholders (Delete all and re-insert)
        // Note: In real production, we might update individual records, but full replacement is easier here.
        db.run("DELETE FROM shareholders WHERE company_id = ?", [id], (err) => {
            if (err) return console.error(err);
            
            const shStmt = db.prepare("INSERT INTO shareholders (id, company_id, name, phone, share, stage, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
            shareholders.forEach(sh => {
                shStmt.run(sh.id, id, sh.name, sh.phone, sh.share, sh.stage, sh.notes);
            });
            shStmt.finalize();
            res.json({ success: true });
        });
    });
});

app.delete('/api/companies/:id', (req, res) => {
    const { id } = req.params;

    db.serialize(() => {
        // Delete shareholders first, then company
        db.run("DELETE FROM shareholders WHERE company_id = ?", [id], (err) => {
            if (err) return res.status(500).json({ error: err.message });
            db.run("DELETE FROM companies WHERE id = ?", [id], (err2) => {
                if (err2) return res.status(500).json({ error: err2.message });
                res.json({ success: true });
            });
        });
    });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
    console.log(`Open your browser at http://localhost:${PORT}/login.html`); // Suggest login.html
});
