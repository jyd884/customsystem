const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, '../database.sqlite');

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        initDb();
    }
});

function initDb() {
    db.serialize(() => {
        // Users Table
        db.run(`CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )`, (err) => {
            if (err) console.error("Error creating users table:", err);
            else {
                // Seed Admin
                db.get("SELECT username FROM users WHERE username = ?", ['admin'], (err, row) => {
                    if (!row) {
                        db.run("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ['admin', 'admin', 'admin']);
                        console.log("Admin user seeded.");
                    }
                });
            }
        });

        // Companies Table
        db.run(`CREATE TABLE IF NOT EXISTS companies (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            created_at TEXT,
            created_by TEXT,
            last_modified TEXT,
            last_modified_by TEXT
        )`);

        // Shareholders Table
        db.run(`CREATE TABLE IF NOT EXISTS shareholders (
            id TEXT PRIMARY KEY,
            company_id TEXT,
            name TEXT,
            phone TEXT,
            share TEXT,
            stage TEXT,
            notes TEXT,
            FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
        )`);
    });
}

module.exports = db;
